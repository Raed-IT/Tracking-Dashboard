"use client";
import type {Map as MlMap,MapLayerMouseEvent,GeoJSONSource} from "maplibre-gl";
import {useEffect} from "react";
import {useTrackingStore} from "@/stores/tracking-store";

export function AircraftLayer({map}:{map:React.RefObject<MlMap|null>}){
 const tracks=useTrackingStore(s=>s.tracks),select=useTrackingStore(s=>s.select);
 useEffect(()=>{const m=map.current;if(!m||!m.isStyleLoaded())return;const data:GeoJSON.FeatureCollection={type:"FeatureCollection",features:[...tracks.values()].filter(t=>t.type==="aircraft").map(t=>({type:"Feature",geometry:{type:"Point",coordinates:[t.longitude,t.latitude]},properties:{id:t.id,callsign:t.callsign,heading:t.heading}}))};
 const source=m.getSource("aircraft") as GeoJSONSource|undefined;if(source)source.setData(data);else{m.addSource("aircraft",{type:"geojson",data});m.addLayer({id:"aircraft",type:"circle",source:"aircraft",paint:{"circle-radius":6,"circle-color":"#22d3ee","circle-stroke-color":"#020617","circle-stroke-width":2}});m.on("click","aircraft",(e:MapLayerMouseEvent)=>{const id=e.features?.[0]?.properties?.id as string|undefined;if(id)select(id)})}},[tracks,map,select]);
 return null;
}
export const DroneLayer=()=>null;export const VehicleLayer=()=>null;export const SensorLayer=()=>null;export const CameraLayer=()=>null;export const GeofenceLayer=()=>null;export const AlertLayer=()=>null;
