"use client";
import "maplibre-gl/dist/maplibre-gl.css";
import maplibregl,{Map as MlMap} from "maplibre-gl";
import {useEffect,useRef} from "react";
import {fetchTracks} from "@/services/api";
import {connectTracking} from "@/services/realtime";
import {useTrackingStore} from "@/stores/tracking-store";
import {AircraftLayer} from "./layers";

export function OperationsMap(){
  const el=useRef<HTMLDivElement>(null),map=useRef<MlMap|null>(null),replace=useTrackingStore(s=>s.replace);
  useEffect(()=>{if(!el.current)return;const disconnect=connectTracking();const m=new maplibregl.Map({container:el.current,style:"https://demotiles.maplibre.org/style.json",center:[0,20],zoom:2.1,attributionControl:false});map.current=m;
    const load=()=>{const b=m.getBounds();fetchTracks(`${b.getWest()},${b.getSouth()},${b.getEast()},${b.getNorth()}`).then(replace).catch(()=>undefined)};m.on("load",load);m.on("moveend",load);return()=>{disconnect();m.remove()};},[replace]);
  return <div className="relative h-full w-full overflow-hidden"><div ref={el} className="h-full w-full"/><div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,transparent_35%,rgba(2,6,23,.28)_100%)]"/><div className="pointer-events-none absolute bottom-4 left-4 rounded-lg border border-white/10 bg-slate-950/75 px-3 py-2 text-[9px] uppercase tracking-wider text-slate-500 backdrop-blur"><span className="text-cyan-300">●</span> Aircraft <span className="ml-3 text-amber-300">●</span> Alerts</div><AircraftLayer map={map}/></div>
}
