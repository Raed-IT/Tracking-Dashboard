"use client";
import Link from "next/link";
import { Database, Maximize2, RadioTower, ShieldAlert, Wifi, X } from "lucide-react";
import { useState } from "react";
import { OperationsMap } from "@/components/map/OperationsMap";
import { AuthGate } from "@/components/auth/AuthGate";
import { OperationsDrawer } from "@/components/navigation/OperationsDrawer";
import { useDashboardController } from "@/controllers/useDashboardController";
import { PageHeader } from "@/components/ui/Page";
import { StatusBadge } from "@/components/ui/StatusBadge";

function SecuredDashboard(){
  const dashboard=useDashboardController(),[fullscreen,setFullscreen]=useState(false);
  const telemetry=dashboard.sources.reduce((sum,s)=>sum+s.messages_per_minute,0);
  const stats=[
    {label:"Active tracks",value:dashboard.metrics.tracks,detail:"aircraft in monitored airspace",icon:RadioTower,accent:"text-cyan-300",bg:"bg-cyan-300/10"},
    {label:"Data sources",value:dashboard.sources.length,detail:`${dashboard.metrics.sources} reporting now`,icon:Wifi,accent:"text-emerald-300",bg:"bg-emerald-300/10"},
    {label:"Active alerts",value:dashboard.metrics.alerts,detail:"requiring operator review",icon:ShieldAlert,accent:"text-amber-300",bg:"bg-amber-300/10"},
    {label:"Telemetry / min",value:Math.round(telemetry),detail:"messages across all feeds",icon:Database,accent:"text-violet-300",bg:"bg-violet-300/10"}
  ];
  return <main className="mx-auto max-w-[1800px] p-4 sm:p-6 xl:p-8">
    <PageHeader eyebrow="OPERATIONS / OVERVIEW" title="Command overview" description="Live multi-source situational awareness, flight telemetry and operational activity."/>
    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map(({label,value,detail,icon:Icon,accent,bg})=><article key={label} className="group relative overflow-hidden rounded-2xl border border-white/[.07] bg-slate-900/70 p-5 shadow-lg shadow-black/10 transition hover:-translate-y-0.5 hover:border-white/10">
        <div className={`mb-5 grid h-10 w-10 place-items-center rounded-xl ${bg} ${accent}`}><Icon size={18}/></div><div className="text-[10px] font-bold uppercase tracking-[.17em] text-slate-500">{label}</div><div className="mt-1 text-3xl font-semibold tracking-tight text-white">{value.toLocaleString()}</div><div className="mt-2 text-xs text-slate-600">{detail}</div>
        <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full border border-white/[.03]"/>
      </article>)}
    </section>
    <section className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
      <section className={`relative overflow-hidden rounded-2xl border border-white/[.07] bg-slate-900/70 shadow-2xl shadow-black/20 ${fullscreen?"fixed inset-4 z-50 xl:inset-6":""}`}>
        <div className="absolute left-4 top-4 z-10 rounded-xl border border-white/10 bg-slate-950/75 px-4 py-3 backdrop-blur-xl"><div className="text-[9px] font-bold uppercase tracking-[.2em] text-cyan-300">Live theater</div><div className="mt-1 text-sm font-medium text-white">Global airspace</div><div className="mt-1 flex items-center gap-1.5 text-[10px] text-slate-500"><i className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300"/> Streaming telemetry</div></div>
        <button onClick={()=>setFullscreen(v=>!v)} className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-slate-950/75 text-slate-400 backdrop-blur-xl hover:text-white" aria-label="Toggle map size">{fullscreen?<X size={16}/>:<Maximize2 size={16}/>}</button>
        <div className={fullscreen?"h-[calc(100vh-3rem)]":"h-[620px]"}><OperationsMap/></div>
      </section>
      <aside className="overflow-hidden rounded-2xl border border-white/[.07] bg-slate-900/70 shadow-lg">
        <div className="flex items-center justify-between border-b border-white/[.06] px-5 py-4"><div><div className="text-[9px] font-bold uppercase tracking-[.18em] text-amber-300">Priority queue</div><h2 className="mt-1 text-sm font-semibold text-white">Active incidents</h2></div><Link href="/alerts" className="text-[11px] text-cyan-300 hover:text-cyan-200">View all</Link></div>
        <div className="divide-y divide-white/[.05]">{dashboard.alerts.slice(0,5).map(alert=><article className="p-4 transition hover:bg-white/[.02]" key={alert.id}><div className="flex items-start justify-between gap-3"><strong className="text-sm text-slate-200">{alert.title}</strong><StatusBadge status={alert.severity}/></div><p className="mt-2 line-clamp-2 text-xs leading-5 text-slate-500">{alert.message??"No additional context available."}</p><div className="mt-3 text-[10px] text-slate-600">{new Date(alert.created_at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})} · {alert.track?.callsign??"Unlinked target"}</div></article>)}{dashboard.alerts.length===0&&<div className="flex min-h-48 items-center justify-center px-5 text-center text-xs text-slate-600">No active alerts. The operation is quiet.</div>}</div>
      </aside>
    </section>
  </main>;
}
export function DashboardShell(){return <AuthGate><OperationsDrawer><SecuredDashboard/></OperationsDrawer></AuthGate>}
