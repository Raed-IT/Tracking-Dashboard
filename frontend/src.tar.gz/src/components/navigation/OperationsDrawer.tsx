
"use client";

import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Activity,
  Bell,
  ChevronLeft,
  Command,
  Database,
  LayoutDashboard,
  Menu,
  RadioTower,
  Search,
  Settings,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";

import { useAuthStore } from "@/stores/auth-store";
import { Button } from "@/components/ui/Button";

const nav = [
  {
    href: "/",
    label: "Overview",
    icon: LayoutDashboard,
  },
  {
    href: "/tracks",
    label: "Live Tracks",
    icon: RadioTower,
  },
  {
    href: "/sources",
    label: "Data Sources",
    icon: Database,
  },
  {
    href: "/alerts",
    label: "Alerts",
    icon: ShieldAlert,
  },
  {
    href: "/health",
    label: "System Health",
    icon: Activity,
  },
  {
    href: "/admin/users",
    label: "Users",
    icon: Users,
    permission: "users.manage" as const,
  },
  {
    href: "/settings",
    label: "Settings",
    icon: Settings,
  },
];

export function OperationsDrawer({
  children,
}: {
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();

  const can = useAuthStore((state) => state.can);
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);

  const [mobile, setMobile] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [palette, setPalette] = useState(false);

  // Command palette shortcut
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (
        (event.metaKey || event.ctrlKey) &&
        event.key.toLowerCase() === "k"
      ) {
        event.preventDefault();
        setPalette(true);
      }

      if (event.key === "Escape") {
        setPalette(false);
        setMobile(false);
      }
    };

    document.addEventListener("keydown", listener);

    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, []);

  const signOut = async () => {
    await logout();
    router.replace("/login");
  };

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/";
    }

    return pathname === href || pathname.startsWith(`${href}/`);
  };

  const initials =
    user?.name
      ?.split(" ")
      .map((part) => part.charAt(0))
      .join("")
      .slice(0, 2)
      .toUpperCase() || "OP";

  const visibleNav = nav.filter(
    (item) => !item.permission || can(item.permission)
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-cyan-300 selection:text-slate-950">
      {/* Mobile overlay */}
      {mobile && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-sm lg:hidden"
          onClick={() => setMobile(false)}
          aria-label="Close navigation"
        />
      )}

      {/* Sidebar */}
      <aside
        className={[
          "fixed inset-y-0 left-0 z-50 flex flex-col",
          "border-r border-white/[.07]",
          "bg-slate-950/95 backdrop-blur-xl",
          "transition-all duration-300",
          "w-[260px]",
          collapsed ? "lg:w-[78px]" : "",
          mobile ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        ].join(" ")}
      >
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 border-b border-white/[.06] px-4">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-cyan-300/20 bg-cyan-300/10 text-cyan-300">
            <RadioTower size={18} />
          </div>

          {!collapsed && (
            <div className="min-w-0">
              <div className="text-sm font-bold tracking-[.18em]">
                FUSION<span className="text-cyan-300">OPS</span>
              </div>

              <div className="text-[9px] uppercase tracking-[.2em] text-slate-600">
                Air operations
              </div>
            </div>
          )}

          {/* Desktop collapse */}
          <button
            type="button"
            className="ml-auto hidden rounded-lg p-2 text-slate-500 transition hover:bg-white/5 hover:text-white lg:block"
            onClick={() => setCollapsed((value) => !value)}
            aria-label={
              collapsed ? "Expand sidebar" : "Collapse sidebar"
            }
          >
            <ChevronLeft
              size={16}
              className={collapsed ? "rotate-180" : ""}
            />
          </button>

          {/* Mobile close */}
          <button
            type="button"
            className="ml-auto rounded-lg p-2 text-slate-500 transition hover:bg-white/5 hover:text-white lg:hidden"
            onClick={() => setMobile(false)}
            aria-label="Close navigation"
          >
            <X size={17} />
          </button>
        </div>

        {/* Workspace */}
        {!collapsed && (
          <div className="mx-3 mt-4 rounded-xl border border-white/[.06] bg-white/[.025] p-3">
            <div className="text-[9px] font-bold uppercase tracking-[.18em] text-slate-600">
              Workspace
            </div>

            <div className="mt-1 truncate text-sm font-medium text-slate-200">
              {user?.organization?.name ?? "Operations"}
            </div>

            <div className="mt-2 flex items-center gap-1.5 text-[10px] text-emerald-300">
              <i className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />
              Secure session
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav className="mt-5 flex-1 space-y-1 overflow-y-auto px-3">
          {visibleNav.map(({ href, label, icon: Icon }) => {
            const active = isActive(href);

            return (
              <Link
                key={href}
                href={href}
                title={collapsed ? label : undefined}
                onClick={() => setMobile(false)}
                className={[
                  "group flex items-center gap-3 rounded-xl px-3 py-2.5",
                  "text-sm transition-all duration-200",
                  active
                    ? "bg-cyan-300/10 text-cyan-200 shadow-inner shadow-cyan-300/5"
                    : "text-slate-400 hover:bg-white/[.04] hover:text-white",
                ].join(" ")}
              >
                <Icon
                  size={17}
                  className={
                    active
                      ? "text-cyan-300"
                      : "text-slate-500 group-hover:text-slate-300"
                  }
                />

                {!collapsed && (
                  <>
                    <span className="flex-1">{label}</span>

                    {href === "/alerts" && (
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-300 shadow-[0_0_8px_rgba(252,211,77,.8)]" />
                    )}
                  </>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="border-t border-white/[.06] p-3">
          {!collapsed && (
            <div className="mb-2 flex items-center gap-3 rounded-xl p-2">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-cyan-300 to-blue-500 text-xs font-bold text-slate-950">
                {initials}
              </span>

              <div className="min-w-0">
                <div className="truncate text-xs font-medium text-slate-200">
                  {user?.name ?? "Operator"}
                </div>

                <div className="truncate text-[10px] uppercase tracking-wider text-slate-600">
                  {user?.role ?? "operator"}
                </div>
              </div>
            </div>
          )}

          <button
            type="button"
            onClick={signOut}
            className={[
              "w-full rounded-xl px-3 py-2 text-left text-xs",
              "text-slate-500 transition",
              "hover:bg-rose-400/5 hover:text-rose-300",
            ].join(" ")}
          >
            {collapsed ? "↗" : "Sign out"}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div
        className={[
          "min-h-screen transition-[padding] duration-300",
          collapsed ? "lg:pl-[78px]" : "lg:pl-[260px]",
        ].join(" ")}
      >
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/[.06] bg-slate-950/80 px-4 backdrop-blur-xl sm:px-6">
          {/* Mobile menu */}
          <Button
            size="icon"
            variant="ghost"
            className="lg:hidden"
            onClick={() => setMobile(true)}
            aria-label="Open navigation"
          >
            <Menu size={18} />
          </Button>

          {/* Search */}
          <button
            type="button"
            onClick={() => setPalette(true)}
            className="flex h-10 min-w-0 max-w-xl flex-1 items-center gap-2 rounded-xl border border-white/[.07] bg-white/[.025] px-3 text-left text-xs text-slate-600 transition hover:border-white/15 hover:text-slate-400"
          >
            <Search size={15} />

            <span className="truncate">
              Search tracks, alerts, sources…
            </span>

            <kbd className="ml-auto hidden rounded-md border border-white/10 px-1.5 py-0.5 text-[9px] text-slate-600 sm:block">
              ⌘ K
            </kbd>
          </button>

          {/* Header actions */}
          <div className="ml-auto flex items-center gap-1">
            <Button
              size="icon"
              variant="ghost"
              aria-label="Notifications"
            >
              <Bell size={17} />
            </Button>

            <span className="ml-1 hidden items-center gap-1.5 rounded-full border border-emerald-400/15 bg-emerald-400/5 px-2.5 py-1.5 text-[9px] font-bold uppercase tracking-wider text-emerald-300 sm:flex">
              <i className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />
              Live
            </span>
          </div>
        </header>

        {/* Page content */}
        <main>{children}</main>
      </div>

      {/* Command Palette */}
      {palette && (
        <div
          className="fixed inset-0 z-[60] grid place-items-start bg-slate-950/75 p-4 pt-[12vh] backdrop-blur-md"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setPalette(false);
            }
          }}
        >
          <section className="w-full max-w-xl overflow-hidden rounded-2xl border border-white/10 bg-slate-900 shadow-2xl">
            {/* Search input */}
            <div className="flex items-center gap-3 border-b border-white/10 px-4 py-4">
              <Command
                size={17}
                className="shrink-0 text-cyan-300"
              />

              <input
                autoFocus
                className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-slate-600"
                placeholder="Jump to a workspace…"
              />

              <button
                type="button"
                onClick={() => setPalette(false)}
                className="rounded-lg p-1 transition hover:bg-white/5"
                aria-label="Close command palette"
              >
                <X size={16} className="text-slate-500" />
              </button>
            </div>

            {/* Commands */}
            <div className="max-h-[60vh] overflow-y-auto p-2">
              {visibleNav.map(({ href, label, icon: Icon }) => (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setPalette(false)}
                  className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-slate-300 transition hover:bg-white/5 hover:text-white"
                >
                  <Icon size={16} className="text-slate-500" />

                  <span>{label}</span>

                  <span className="ml-auto text-[10px] text-slate-600">
                    ↵
                  </span>
                </Link>
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

